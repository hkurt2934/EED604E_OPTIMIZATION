% Parameters
a = 1; b = 0.5; % Plant parameters
gamma = 1; % Adaptation gains

% Time vector
dt = 0.1;
t = 0:dt:10-dt;

% Initial conditions
y = 0; y_m = 0; e = 0;
theta1 = 0; theta2 = 0;

% Input (reference signal)
u_c = 1; % Step input

% Preallocate arrays
y_arr = zeros(size(t));
y_m_arr = zeros(size(t));
e_arr = zeros(size(t));
theta1_arr = zeros(size(t));
theta2_arr = zeros(size(t));

for k = 1:length(t)
    % Reference model dynamics
    dydt_m = 2 * u_c - 2 * y_m;
    y_m = y_m + dydt_m * dt;
    
    % Plant dynamics
    u = theta1 * u_c - theta2 * y;
    dydt = -a * y + b * u;
    y = y + dydt * dt;
    
    % Error
    e = y - y_m;
    
    % Adaptive laws
    dtheta1 = -gamma * e * u_c;
    dtheta2 = gamma * e * y;
    theta1 = theta1 + dtheta1 * dt;
    theta2 = theta2 + dtheta2 * dt;
    
    % Store values
    y_arr(k) = y;
    y_m_arr(k) = y_m;
    e_arr(k) = e;
    theta1_arr(k) = theta1;
    theta2_arr(k) = theta2;
end

% Plot results
figure;
subplot(3,1,1); plot(t, y_arr, 'r', t, y_m_arr, 'b'); 
title('System Output vs Reference Output'); legend('y', 'y_m');

subplot(3,1,2); plot(t, e_arr); title('Tracking Error'); xlabel('Time'); ylabel('e(t)');

subplot(3,1,3); plot(t, theta1_arr, t, theta2_arr);
title('Adaptive Parameters'); legend('\theta_1', '\theta_2');
